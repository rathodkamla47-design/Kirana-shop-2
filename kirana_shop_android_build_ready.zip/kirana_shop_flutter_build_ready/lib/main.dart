import 'package:flutter/material.dart';

void main() => runApp(const KiranaShopApp());

class Product {
  final String name, category;
  final double price;
  int stock;
  Product(this.name, this.category, this.price, this.stock);
}

final products = <Product>[
  Product('Aashirvaad Atta 5kg', 'Atta & Rice', 299, 20),
  Product('Tata Salt 1kg', 'Grocery', 28, 50),
  Product('Fortune Sunflower Oil 1L', 'Oil', 135, 30),
  Product('Amul Taaza Milk 1L', 'Dairy', 62, 25),
  Product('Tata Tea 250g', 'Tea & Coffee', 115, 18),
  Product('Parle-G Biscuits', 'Biscuits', 20, 60),
  Product('Surf Excel 1kg', 'Cleaning', 145, 15),
  Product('Maggi 70g', 'Snacks', 15, 80),
];

class KiranaShopApp extends StatelessWidget {
  const KiranaShopApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Kirana Shop',
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.green),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final cart = <Product, int>{};
  int tab = 0;

  void add(Product p) {
    setState(() => cart[p] = (cart[p] ?? 0) + 1);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${p.name} cart में add हो गया')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _home(context),
      CartPage(cart: cart, onChanged: () => setState(() {})),
      const AdminPage(),
    ];
    return Scaffold(
      body: pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.storefront), label: 'Shop'),
          NavigationDestination(icon: Icon(Icons.shopping_cart), label: 'Cart'),
          NavigationDestination(icon: Icon(Icons.admin_panel_settings), label: 'Admin'),
        ],
      ),
    );
  }

  Widget _home(BuildContext context) => SafeArea(
    child: CustomScrollView(slivers: [
      SliverAppBar(
        floating: true,
        title: const Text('Kirana Shop'),
        actions: [
          IconButton(icon: const Icon(Icons.receipt_long), onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const OrdersPage()));
          })
        ],
      ),
      SliverToBoxAdapter(child: Padding(
        padding: const EdgeInsets.all(16),
        child: TextField(
          decoration: InputDecoration(
            hintText: 'Product search करें...',
            prefixIcon: const Icon(Icons.search),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
      )),
      const SliverToBoxAdapter(child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16),
        child: Text('Categories', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      )),
      SliverToBoxAdapter(child: SizedBox(
        height: 100,
        child: ListView(
          padding: const EdgeInsets.all(12),
          scrollDirection: Axis.horizontal,
          children: ['Atta & Rice','Grocery','Oil','Dairy','Tea & Coffee','Snacks','Cleaning']
            .map((x) => Card(child: Padding(
              padding: const EdgeInsets.all(16),
              child: Center(child: Text(x)),
            ))).toList(),
        ),
      )),
      const SliverToBoxAdapter(child: Padding(
        padding: EdgeInsets.fromLTRB(16, 8, 16, 8),
        child: Text('Popular Products', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      )),
      SliverList(delegate: SliverChildBuilderDelegate((context, i) {
        final p = products[i];
        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          child: ListTile(
            leading: CircleAvatar(child: Text(p.name.substring(0,1))),
            title: Text(p.name),
            subtitle: Text('${p.category} • Stock: ${p.stock}'),
            trailing: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('₹${p.price.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.bold)),
                SizedBox(height: 28, child: ElevatedButton(onPressed: p.stock > 0 ? () => add(p) : null, child: const Text('Add')))
              ],
            ),
          ),
        );
      }, childCount: products.length)),
    ]),
  );
}

class CartPage extends StatelessWidget {
  final Map<Product,int> cart;
  final VoidCallback onChanged;
  const CartPage({super.key, required this.cart, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final total = cart.entries.fold<double>(0, (s,e) => s + e.key.price * e.value);
    return SafeArea(child: Scaffold(
      appBar: AppBar(title: const Text('My Cart')),
      body: cart.isEmpty ? const Center(child: Text('Cart खाली है')) : Column(
        children: [
          Expanded(child: ListView(children: cart.entries.map((e) => ListTile(
            title: Text(e.key.name), subtitle: Text('₹${e.key.price.toStringAsFixed(0)} × ${e.value}'),
            trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () { cart.remove(e.key); onChanged(); }),
          )).toList())),
          Padding(padding: const EdgeInsets.all(16), child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Total: ₹${total.toStringAsFixed(0)}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              FilledButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CheckoutPage(total: total))),
                child: const Text('Checkout'))
            ],
          ))
        ],
      ),
    ));
  }
}

class CheckoutPage extends StatelessWidget {
  final double total;
  const CheckoutPage({super.key, required this.total});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Checkout')),
    body: Padding(padding: const EdgeInsets.all(20), child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Order Total: ₹${total.toStringAsFixed(0)}', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 24),
        const TextField(decoration: InputDecoration(labelText: 'Customer Name', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        const TextField(decoration: InputDecoration(labelText: 'Mobile Number', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        const TextField(maxLines: 3, decoration: InputDecoration(labelText: 'Delivery Address', border: OutlineInputBorder())),
        const SizedBox(height: 16),
        const ListTile(leading: Icon(Icons.money), title: Text('Cash on Delivery'), subtitle: Text('Online payment बाद में जोड़ा जा सकता है')),
        const Spacer(),
        SizedBox(width: double.infinity, child: FilledButton(
          onPressed: () => showDialog(context: context, builder: (_) => AlertDialog(
            title: const Text('Order Placed 🎉'),
            content: const Text('आपका order successfully place हो गया।'),
            actions: [TextButton(onPressed: () => Navigator.popUntil(context, (r) => r.isFirst), child: const Text('Done'))],
          )),
          child: const Text('Place Order'),
        ))
      ],
    )),
  );
}

class OrdersPage extends StatelessWidget {
  const OrdersPage({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('My Orders')),
    body: ListView(padding: const EdgeInsets.all(16), children: const [
      Card(child: ListTile(leading: Icon(Icons.inventory_2), title: Text('Order #1001'), subtitle: Text('₹674 • Delivered'), trailing: Icon(Icons.check_circle))),
      Card(child: ListTile(leading: Icon(Icons.local_shipping), title: Text('Order #1002'), subtitle: Text('₹299 • Out for Delivery'), trailing: Icon(Icons.timelapse))),
    ]),
  );
}

class AdminPage extends StatelessWidget {
  const AdminPage({super.key});
  @override Widget build(BuildContext context) {
    final stock = products.fold<int>(0, (s,p) => s+p.stock);
    return Scaffold(
      appBar: AppBar(title: const Text('Admin Dashboard')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [
          Expanded(child: _stat('Orders', '24', Icons.receipt)),
          const SizedBox(width: 8),
          Expanded(child: _stat('Products', '${products.length}', Icons.inventory)),
          const SizedBox(width: 8),
          Expanded(child: _stat('Stock', '$stock', Icons.warehouse)),
        ]),
        const SizedBox(height: 20),
        const Text('Product Management', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        ...products.map((p) => Card(child: ListTile(
          title: Text(p.name), subtitle: Text('₹${p.price.toStringAsFixed(0)} • Stock ${p.stock}'),
          trailing: IconButton(icon: const Icon(Icons.edit), onPressed: () {}),
        ))),
        const SizedBox(height: 16),
        const Text('Sales Summary', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const Card(child: ListTile(title: Text('Today'), trailing: Text('₹8,450', style: TextStyle(fontWeight: FontWeight.bold)))),
        const Card(child: ListTile(title: Text('This Month'), trailing: Text('₹1,84,250', style: TextStyle(fontWeight: FontWeight.bold)))),
      ]),
    );
  }

  Widget _stat(String label, String value, IconData icon) => Card(
    child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [
      Icon(icon, size: 28), const SizedBox(height: 6), Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), Text(label)
    ])),
  );
}
