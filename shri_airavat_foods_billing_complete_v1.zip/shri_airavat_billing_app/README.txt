Shri Airavat Foods Billing App
Features planned in this starter project:
- Hindi + English UI
- New Bill
- Customers
- Products without stock management
- Optional GST per bill
- Discount
- Payment details
- Bill history
- Sales reports
- Print/WhatsApp sharing
- Settings
- Admin PIN
- Backup/restore

Open the Android project in Android Studio or use the included GitHub workflow after uploading this ZIP.
